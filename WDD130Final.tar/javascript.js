var rock = document.getElementById('rock');

rock.addEventListener('click', function(){
    window.location = 'rpsls.html';
});

var magic = document.getElementById('magic');

magic.addEventListener('click', function(){
    window.location = 'magic_8_ball.html'; 
});

